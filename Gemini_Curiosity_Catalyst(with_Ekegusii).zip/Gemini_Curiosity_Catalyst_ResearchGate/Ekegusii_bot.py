def ekegusii_chatbot(prompt, context={"language": "Ekegusii", "region": "Nyamira", "plugin": "Gemini Curiosity Catalyst"}):
    responses = {
        "Bwakire?": "Ee, Bwakire Buya!",  # Morning greeting in Ting’a
        "Bwakiete": "Ee, bwakiete kare!",  # Narrative response
        "Mwabokire?": "Ee, twabokire buya!",  # Group greeting
        "Mwaetire": "Ee, twaetire buya!",  # Group success/passing
        "Bwairire?": "Ee, Bwairire Buya!",  # Evening greeting
        "Ogoeta": "Ee, ogoeta!",  # Just passing by
        "Ng’ai mwaberete?": "Twaberete Ting’a!",  # We were staying in Ting’a
        "Naetire": "Ee, gwaetire!"  # I succeeded -> Yes, you succeeded
    }
    return responses.get(prompt, curiosity_catalyst(prompt, context))
